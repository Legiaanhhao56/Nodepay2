banner = """

            Nodepay bot for running with multyple proxy
                
"""